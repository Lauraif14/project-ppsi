import React, { useEffect, useState } from "react";
import api from "../api/axios";

const RiwayatPiket = () => {
  const [riwayat, setRiwayat] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    api.get("/riwayat", { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setRiwayat(res.data))
      .catch(() => setRiwayat([]))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p>Memuat riwayat...</p>;
  if (riwayat.length === 0) return <p>Tidak ada riwayat piket.</p>;

  return (
    <div className="p-6 border-2 border-black rounded-xl bg-white shadow-lg mt-6">
      <h3 className="text-xl font-bold mb-4 text-gray-800">Riwayat Piket</h3>
      <ul className="space-y-3">
        {riwayat.map((r, i) => (
          <li key={i} className="p-3 border rounded-lg bg-gray-50">
            <p><strong>Tanggal:</strong> {new Date(r.tanggal).toLocaleDateString('id-ID')}</p>
            <p><strong>Jam Masuk:</strong> {r.waktu_masuk}</p>
            <p><strong>Jam Keluar:</strong> {r.waktu_keluar || '-'}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RiwayatPiket;
