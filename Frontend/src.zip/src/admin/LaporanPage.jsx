// src/pages/LaporanPage.jsx
import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Users, Package, CalendarDays, Eye, Download } from "lucide-react";
import html2canvas from "html2canvas";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import api from "../api/axios"; // axios instance kamu

const LaporanPage = () => {
  const [dataType, setDataType] = useState("absensi");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const [laporanPiket, setLaporanPiket] = useState([]);
  const tableRef = useRef();

  // Dummy data untuk absensi & inventaris
  const dummyAbsensi = [
    { id: 1, name: "Ahmad Rizki", date: "2025-09-01", status: "Hadir", time: "08:00" },
    { id: 2, name: "Siti Nurhaliza", date: "2025-09-01", status: "Tidak Hadir", time: "-" },
    { id: 3, name: "Budi Santoso", date: "2025-09-01", status: "Hadir", time: "08:15" },
    { id: 4, name: "Rina Marlina", date: "2025-09-01", status: "Izin", time: "-" },
  ];

  const dummyInventaris = [
    { id: 1, item: "Kursi Plastik", date: "2025-09-01", checkedBy: "Ahmad Rizki", condition: "Baik", quantity: 50 },
    { id: 2, item: "Meja Lipat", date: "2025-09-01", checkedBy: "Siti Nurhaliza", condition: "Hilang", quantity: 25 },
    { id: 3, item: "Sound System", date: "2025-09-01", checkedBy: "Budi Santoso", condition: "Baik", quantity: 2 },
    { id: 4, item: "Proyektor", date: "2025-09-01", checkedBy: "Rina Marlina", condition: "Dipinjam", quantity: 1 },
  ];

  // Ambil data piket nyata dari backend
  useEffect(() => {
    if (dataType === "piket") {
      const fetchData = async () => {
        try {
          const res = await api.get(`/riwayat/all`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          });
          setLaporanPiket(res.data.data || []);
        } catch (error) {
          console.error("Gagal mengambil data piket:", error);
        }
      };
      fetchData();
    }
  }, [dataType, selectedDate]);

  // Pilih data yang akan ditampilkan berdasarkan tab
  const data =
    dataType === "absensi"
      ? dummyAbsensi.filter((d) => d.date === selectedDate)
      : dataType === "inventaris"
      ? dummyInventaris.filter((d) => d.date === selectedDate)
      : laporanPiket.filter((d) => d.tanggal_piket === selectedDate);

  // Statistik
  const absensiStats = {
    hadir: data.filter((i) => i.status === "Hadir").length,
    tidak: data.filter((i) => i.status === "Tidak Hadir").length,
    izin: data.filter((i) => i.status === "Izin").length,
    total: data.length,
  };

  const inventarisStats = {
    baik: data.filter((i) => i.condition === "Baik").length,
    hilang: data.filter((i) => i.condition === "Hilang").length,
    dipinjam: data.filter((i) => i.condition === "Dipinjam").length,
    total: data.length,
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      "Hadir": "bg-green-200 text-green-900",
      "Tidak Hadir": "bg-red-200 text-red-900",
      "Izin": "bg-yellow-200 text-yellow-900",
    };
    return statusConfig[status] || "bg-gray-200 text-gray-900";
  };

  const getConditionBadge = (condition) => {
    const conditionConfig = {
      "Baik": "bg-green-200 text-green-900",
      "Hilang": "bg-red-200 text-red-900",
      "Dipinjam": "bg-yellow-200 text-yellow-900",
    };
    return conditionConfig[condition] || "bg-gray-200 text-gray-900";
  };

  const handleExport = () => {
    if (tableRef.current) {
      const buttons = tableRef.current.querySelectorAll("button");
      buttons.forEach((btn) => (btn.style.display = "none"));

      html2canvas(tableRef.current, { scale: 2 })
        .then((canvas) => {
          const link = document.createElement("a");
          link.download = `laporan_${dataType}_${selectedDate}.png`;
          link.href = canvas.toDataURL("image/png");
          link.click();
        })
        .finally(() => {
          buttons.forEach((btn) => (btn.style.display = "inline-block"));
        });
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar activeMenu="laporan" setActiveMenu={() => {}} />
      <div className="flex-1 flex flex-col">
        <Navbar />

        <motion.div
          className="flex-1 p-6 space-y-6 overflow-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-1">Laporan Harian</h1>
              <p className="text-gray-600">
                Monitor absensi pengurus, kondisi inventaris, dan riwayat piket
              </p>
            </div>
            <div className="flex gap-3 items-center">
              <div className="flex items-center gap-2">
                <CalendarDays size={18} className="text-gray-600" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-3 py-2 border-2 border-black rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
              <button
                onClick={handleExport}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-blue-300 to-blue-400 text-white font-medium shadow-md hover:shadow-lg transition-all duration-200 border-2 border-black"
              >
                <Download size={18} />
                Export
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 bg-white p-1 rounded-lg shadow-sm border-2 border-black w-fit">
            {["absensi", "inventaris", "piket"].map((type) => (
              <button
                key={type}
                className={`px-4 py-2 rounded-md font-medium transition-all duration-200 border-2 ${
                  dataType === type
                    ? "bg-blue-300 text-white shadow-md border-black"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-50 border-transparent hover:border-gray-300"
                }`}
                onClick={() => setDataType(type)}
              >
                {type === "absensi" ? "🧍 Absensi" : type === "inventaris" ? "📦 Inventaris" : "🗓️ Piket"}
              </button>
            ))}
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {dataType === "inventaris" ? (
              <>
                <div className="bg-green-100 p-4 rounded-xl text-green-900 shadow-md border-2 border-black">
                  <p className="text-sm">Kondisi Baik</p>
                  <p className="text-2xl font-bold">{inventarisStats.baik}</p>
                </div>
                <div className="bg-red-100 p-4 rounded-xl text-red-900 shadow-md border-2 border-black">
                  <p className="text-sm">Hilang</p>
                  <p className="text-2xl font-bold">{inventarisStats.hilang}</p>
                </div>
                <div className="bg-yellow-100 p-4 rounded-xl text-yellow-900 shadow-md border-2 border-black">
                  <p className="text-sm">Dipinjam</p>
                  <p className="text-2xl font-bold">{inventarisStats.dipinjam}</p>
                </div>
                <div className="bg-blue-100 p-4 rounded-xl text-blue-900 shadow-md border-2 border-black">
                  <p className="text-sm">Total Item</p>
                  <p className="text-2xl font-bold">{inventarisStats.total}</p>
                </div>
              </>
            ) : (
              <>
                <div className="bg-green-100 p-4 rounded-xl text-green-900 shadow-md border-2 border-black">
                  <p className="text-sm">Hadir</p>
                  <p className="text-2xl font-bold">{absensiStats.hadir}</p>
                </div>
                <div className="bg-red-100 p-4 rounded-xl text-red-900 shadow-md border-2 border-black">
                  <p className="text-sm">Tidak Hadir</p>
                  <p className="text-2xl font-bold">{absensiStats.tidak}</p>
                </div>
                <div className="bg-yellow-100 p-4 rounded-xl text-yellow-900 shadow-md border-2 border-black">
                  <p className="text-sm">Izin</p>
                  <p className="text-2xl font-bold">{absensiStats.izin}</p>
                </div>
                <div className="bg-blue-100 p-4 rounded-xl text-blue-900 shadow-md border-2 border-black">
                  <p className="text-sm">Total</p>
                  <p className="text-2xl font-bold">{absensiStats.total}</p>
                </div>
              </>
            )}
          </div>

          {/* Tabel Laporan */}
          <div ref={tableRef} className="bg-white rounded-xl shadow-sm border-2 border-black overflow-hidden mt-4">
            <div className="px-6 py-4 border-b-2 border-black">
              <h2 className="text-lg font-semibold text-gray-900">
                {dataType === "absensi"
                  ? "📋 Laporan Absensi"
                  : dataType === "inventaris"
                  ? "📦 Laporan Inventaris"
                  : "🗓️ Laporan Piket"}
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                Data tanggal {selectedDate} • {data.length} entri
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                    {dataType === "inventaris" ? (
                      <>
                        <th className="px-6 py-3">Nama Barang</th>
                        <th className="px-6 py-3">Jumlah</th>
                        <th className="px-6 py-3">Dicek Oleh</th>
                        <th className="px-6 py-3">Kondisi</th>
                      </>
                    ) : (
                      <>
                        <th className="px-6 py-3">Nama Pengurus</th>
                        <th className="px-6 py-3">Tanggal / Jam</th>
                        <th className="px-6 py-3">Status</th>
                      </>
                    )}
                    <th className="px-6 py-3">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((item, index) => (
                    <tr key={item.id || index} className="hover:bg-gray-50">
                      <td className="px-6 py-4">{index + 1}</td>
                      {dataType === "inventaris" ? (
                        <>
                          <td className="px-6 py-4">{item.item}</td>
                          <td className="px-6 py-4">{item.quantity} unit</td>
                          <td className="px-6 py-4">{item.checkedBy}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getConditionBadge(item.condition)}`}>
                              {item.condition}
                            </span>
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="px-6 py-4">{item.nama_lengkap || item.name}</td>
                          <td className="px-6 py-4">
                            {item.waktu_masuk
                              ? new Date(item.waktu_masuk).toLocaleTimeString("id-ID")
                              : item.time || "-"}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(item.status)}`}>
                              {item.status}
                            </span>
                          </td>
                        </>
                      )}
                      <td className="px-6 py-4">
                        <button className="text-blue-600 hover:text-blue-800 p-1 hover:bg-blue-50 rounded transition-colors">
                          <Eye size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LaporanPage;
