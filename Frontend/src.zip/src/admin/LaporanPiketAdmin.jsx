import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Users, CalendarDays, Eye, Download } from "lucide-react";
import html2canvas from "html2canvas";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import api from "../api/axios"; // pastikan kamu punya axios instance di sini

const LaporanPiketAdmin = () => {
  const [laporan, setLaporan] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const tableRef = useRef();

  // Ambil data laporan piket dari backend
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await api.get(`/laporan/piket?date=${selectedDate}`);
        setLaporan(res.data || []);
      } catch (error) {
        console.error("Gagal mengambil laporan piket:", error);
      }
    };
    fetchData();
  }, [selectedDate]);

  // Hitung total status
  const stats = {
    hadir: laporan.filter((item) => item.status === "Hadir").length,
    tidak: laporan.filter((item) => item.status === "Tidak Hadir").length,
    izin: laporan.filter((item) => item.status === "Izin").length,
    total: laporan.length,
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      Hadir: "bg-green-200 text-green-900",
      "Tidak Hadir": "bg-red-200 text-red-900",
      Izin: "bg-yellow-200 text-yellow-900",
    };
    return statusConfig[status] || "bg-gray-200 text-gray-900";
  };

  const handleExport = () => {
    if (tableRef.current) {
      const buttons = tableRef.current.querySelectorAll("button");
      buttons.forEach((btn) => (btn.style.display = "none"));

      html2canvas(tableRef.current, { scale: 2 })
        .then((canvas) => {
          const link = document.createElement("a");
          link.download = `laporan_piket_${selectedDate}.png`;
          link.href = canvas.toDataURL("image/png");
          link.click();
        })
        .finally(() => {
          buttons.forEach((btn) => (btn.style.display = "inline-block"));
        });
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar activeMenu="laporan" setActiveMenu={() => {}} />
      <div className="flex-1 flex flex-col">
        <Navbar />

        <motion.div
          className="flex-1 p-6 space-y-6 overflow-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-1">Laporan Piket</h1>
              <p className="text-gray-600">Pantau kehadiran pengurus berdasarkan jadwal piket harian</p>
            </div>
            <div className="flex gap-3 items-center">
              <div className="flex items-center gap-2">
                <CalendarDays size={18} className="text-gray-600" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-3 py-2 border-2 border-black rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
              <button
                onClick={handleExport}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-blue-300 to-blue-400 text-white font-medium shadow-md hover:shadow-lg transition-all duration-200 border-2 border-black"
              >
                <Download size={18} />
                Export
              </button>
            </div>
          </div>

          {/* Statistik Kehadiran */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-green-100 p-4 rounded-xl text-green-900 shadow-md border-2 border-black">
              <div className="flex items-center">
                <Users size={20} className="mr-3" />
                <div>
                  <p className="text-sm">Hadir</p>
                  <p className="text-2xl font-bold">{stats.hadir}</p>
                </div>
              </div>
            </div>
            <div className="bg-red-100 p-4 rounded-xl text-red-900 shadow-md border-2 border-black">
              <div className="flex items-center">
                <Users size={20} className="mr-3" />
                <div>
                  <p className="text-sm">Tidak Hadir</p>
                  <p className="text-2xl font-bold">{stats.tidak}</p>
                </div>
              </div>
            </div>
            <div className="bg-yellow-100 p-4 rounded-xl text-yellow-900 shadow-md border-2 border-black">
              <div className="flex items-center">
                <Users size={20} className="mr-3" />
                <div>
                  <p className="text-sm">Izin</p>
                  <p className="text-2xl font-bold">{stats.izin}</p>
                </div>
              </div>
            </div>
            <div className="bg-blue-100 p-4 rounded-xl text-blue-900 shadow-md border-2 border-black">
              <div className="flex items-center">
                <Users size={20} className="mr-3" />
                <div>
                  <p className="text-sm">Total Pengurus</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Tabel Laporan */}
          <div ref={tableRef} className="bg-white rounded-xl shadow-sm border-2 border-black overflow-hidden mt-4">
            <div className="px-6 py-4 border-b-2 border-black">
              <h2 className="text-lg font-semibold text-gray-900">📋 Laporan Absensi Piket</h2>
              <p className="text-sm text-gray-600 mt-1">
                Data tanggal {selectedDate} • {laporan.length} pengurus
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Pengurus</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Waktu</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {laporan.map((item, index) => (
                    <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{index + 1}</td>
                      <td className="px-6 py-4 whitespace-nowrap flex items-center">
                        <div className="w-8 h-8 bg-blue-200 text-blue-900 rounded-full flex items-center justify-center font-semibold mr-3">
                          {item.nama.charAt(0)}
                        </div>
                        {item.nama}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900">{item.waktu || "-"}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(item.status)}`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium">
                        <button className="text-blue-600 hover:text-blue-800 p-1 hover:bg-blue-50 rounded transition-colors">
                          <Eye size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LaporanPiketAdmin;
